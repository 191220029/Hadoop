cp -r ./* /mnt/hgfs/labs/lab2
