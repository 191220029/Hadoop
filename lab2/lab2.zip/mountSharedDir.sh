vmhgfs-fuse -o allow_other .host:/ /mnt/hgfs
