zip -q -r lab2.zip ./
